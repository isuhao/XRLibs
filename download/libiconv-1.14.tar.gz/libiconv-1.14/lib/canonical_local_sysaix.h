  (int)(long)&((struct stringpool_t *)0)->stringpool_str307,
  (int)(long)&((struct stringpool_t *)0)->stringpool_str543,
