  (int)(long)&((struct stringpool_t *)0)->stringpool_str258,
  (int)(long)&((struct stringpool_t *)0)->stringpool_str390,
